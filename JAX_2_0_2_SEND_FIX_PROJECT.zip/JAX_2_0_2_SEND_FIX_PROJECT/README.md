# JAX Gemini Automator 2.0.2

This is a fresh build from the 2.0 baseline with a targeted fix for Gemini's visually visible but accessibility-unlabeled Send/Generate arrow.

The automation still processes one queued prompt at a time and stops on failures rather than skipping.
