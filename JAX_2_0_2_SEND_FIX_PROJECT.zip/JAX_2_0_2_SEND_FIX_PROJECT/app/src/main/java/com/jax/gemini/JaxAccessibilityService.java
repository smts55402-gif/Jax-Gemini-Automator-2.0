package com.jax.gemini;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.io.InputStream;
import java.util.*;
import java.util.concurrent.*;

/**
 * Accessibility automation engine for a user-initiated Gemini image batch.
 * The persisted queue cursor is the source of truth. A job is only completed
 * after the output image is verified in the requested destination.
 */
public class JaxAccessibilityService extends AccessibilityService {
    static volatile JaxAccessibilityService inst;

    volatile boolean running = false;
    volatile boolean stopRequested = false;
    volatile Thread worker;

    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private volatile String activePackage = "";

    private static final String[] GEMINI_COMPOSER_HINTS = {
            "ask gemini", "describe your image", "type a prompt", "ask away"
    };
    private static final String[] GENERATE_LABELS = {
            "generate image", "create image", "generate", "send message", "send", "submit", "create"
    };
    private static final String[] ATTACH_LABELS = {
            "add files", "add file", "attach", "add image", "upload", "photo"
    };
    private static final String[] MORE_LABELS = {
            "more options", "more", "options", "menu"
    };
    private static final String[] DOWNLOAD_LABELS = {
            "download image", "download full size", "download full resolution",
            "save image", "download", "save"
    };
    private static final String[] REMOVE_LABELS = {
            "remove attachment", "remove file", "remove image"
    };

    public static boolean enabled(Context c) {
        try {
            String s = Settings.Secure.getString(
                    c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (s == null) return false;
            String pkg = c.getPackageName().toLowerCase(Locale.US);
            return s.toLowerCase(Locale.US).contains(pkg);
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isRunning() {
        return inst != null && inst.running;
    }

    public static void startBatch(Context c) {
        if (inst != null) inst.begin();
        else Toasts.show(c, "Jax Accessibility Service is not connected");
    }

    public static void stopBatch(Context c) {
        if (inst != null) inst.stopNow();
        else Toasts.show(c, "Jax is not running");
    }

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
        activePackage = "";
    }

    @Override public void onDestroy() {
        stopRequested = true;
        Thread t = worker;
        if (t != null) t.interrupt();
        exec.shutdownNow();
        if (inst == this) inst = null;
        super.onDestroy();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        CharSequence p = e == null ? null : e.getPackageName();
        if (p != null) activePackage = p.toString();
    }

    @Override public void onInterrupt() {}

    private void begin() {
        if (running) return;
        stopRequested = false;
        running = true;
        exec.submit(() -> {
            worker = Thread.currentThread();
            try { runAll(); }
            finally {
                worker = null;
                running = false;
            }
        });
    }

    private void stopNow() {
        stopRequested = true;
        Thread t = worker;
        if (t != null) t.interrupt();
    }

    private void checkStop() throws StopRequestedException {
        if (stopRequested || Thread.currentThread().isInterrupted())
            throw new StopRequestedException();
    }

    private static final class StopRequestedException extends Exception {
        StopRequestedException() { super("Stopped by user"); }
    }

    private void runAll() {
        ArrayList<Prompt> queue = JaxStore.loadQueue(this);
        int cursor = JaxStore.cursor(this);
        String browser = JaxStore.setting(this, "browserPackage", "net.quetta.browser");

        if (queue.isEmpty()) {
            notifyUser("Jax", "Queue is empty");
            return;
        }
        if (cursor >= queue.size()) {
            notifyUser("Jax", "Batch already completed");
            return;
        }

        String runId = JaxStore.setting(this, "runId", "");
        if (runId.isEmpty()) {
            runId = "Run-" + new java.text.SimpleDateFormat("yyyy-MM-dd-HHmmss", Locale.US).format(new Date());
            if (!JaxStore.saveSettings(this, "runId", runId)) {
                notifyUser("Jax stopped", "Could not persist run ID");
                return;
            }
        }

        try {
            for (int i = cursor; i < queue.size(); i++) {
                checkStop();
                Prompt p = queue.get(i);

                // If a prior process died after marking a job done but before moving the cursor,
                // verify the recorded output before advancing. Otherwise retry the job.
                if ("done".equals(p.status) && outputStillValid(p)) {
                    queue.get(i).stage = "COMPLETED";
                    if (!saveQueueOrStop(queue, i + 1)) return;
                    continue;
                }

                p.status = "working";
                p.error = "";
                p.stage = "START";
                p.outputName = "";
                saveQueueOrNotify(queue, i);

                int maxRetries = Math.max(0, Math.min(5, parseIntSetting("retries", 2)));
                String lastError = "Unknown error";
                boolean complete = false;

                for (int attempt = 0; attempt <= maxRetries; attempt++) {
                    try {
                        if (attempt > 0) {
                            p.stage = "RETRY " + attempt;
                            p.status = "working";
                            saveQueueOrNotify(queue, i);
                            notifyUser("Jax retry", label(p, i) + " — attempt " + (attempt + 1));
                            sleepChecked(1200L);
                        }

                        processOne(p, i, queue.size(), browser, runId);
                        p.status = "done";
                        p.error = "";
                        p.stage = "COMPLETED";
                        if (!saveQueueOrStop(queue, i + 1)) return;
                        complete = true;
                        break;

                    } catch (StopRequestedException stop) {
                        p.status = "paused";
                        p.error = "Stopped by user";
                        p.stage = "PAUSED";
                        saveQueueOrNotify(queue, i);
                        notifyUser("Jax paused", label(p, i));
                        return;

                    } catch (Exception ex) {
                        lastError = ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
                        p.status = "working";
                        p.error = lastError;
                        p.stage = "FAILED: " + trimError(lastError);
                        saveQueueOrNotify(queue, i);
                        if (stopRequested) {
                            p.status = "paused";
                            p.error = "Stopped by user";
                            p.stage = "PAUSED";
                            saveQueueOrNotify(queue, i);
                            notifyUser("Jax paused", label(p, i));
                            return;
                        }
                    }
                }

                if (!complete) {
                    p.status = "error";
                    p.error = lastError;
                    p.stage = "PAUSED_ON_ERROR";
                    saveQueueOrNotify(queue, i);
                    notifyUser("Jax paused at " + label(p, i), trimError(lastError));
                    return; // Never skip a failed prompt.
                }
            }

            JaxStore.saveSettings(this, "lastRunId", runId);
            JaxStore.saveSettings(this, "runId", "");
            notifyUser("Jax batch complete", "Completed " + queue.size() + " prompts");

        } catch (StopRequestedException stop) {
            int c = JaxStore.cursor(this);
            notifyUser("Jax paused", "Resume starts from " + (c < queue.size() ? label(queue.get(c), c) : "the next unfinished prompt"));
        } catch (Exception ex) {
            notifyUser("Jax stopped", trimError(ex.getMessage() == null ? "Unexpected error" : ex.getMessage()));
        }
    }

    private boolean saveQueueOrStop(ArrayList<Prompt> q, int cursor) throws StopRequestedException {
        checkStop();
        if (!JaxStore.saveQueue(this, q, cursor)) {
            notifyUser("Jax stopped", "Could not persist queue state");
            return false;
        }
        return true;
    }

    private void saveQueueOrNotify(ArrayList<Prompt> q, int cursor) {
        if (!JaxStore.saveQueue(this, q, cursor))
            notifyUser("Jax warning", "Queue state could not be saved");
    }

    private void processOne(Prompt p, int index, int total, String browser, String runId) throws Exception {
        status("Jax " + label(p, index) + "  " + (index + 1) + "/" + total);

        // Recovery-first: if a previous run already downloaded an image but died before output copy,
        // finish that exact image instead of generating a duplicate.
        if (tryFinishPendingDownload(p, index, runId)) return;

        setStage(p, index, "OPEN_GEMINI");
        ensureGemini(browser);

        // New chat is optional. If the current Gemini UI does not expose it, we continue safely.
        tapText("New chat|New conversation", true, 1500L);
        sleepChecked(350L);

        setStage(p, index, "CLEAR_ATTACHMENTS");
        clearChatAttachments();
        waitForAttachmentCount(0, 2000L);

        setStage(p, index, "MATCH_REFERENCES");
        ArrayList<JaxStore.RefItem> refs = matchedReferenceItems(p);
        validateReferenceSelection(p, refs);
        if (!refs.isEmpty()) {
            for (JaxStore.RefItem r : refs) {
                checkStop();
                JaxStore.copyRefToDownloads(this, r.uri, r.name);
            }
            uploadReferencesOneByOne(refs);
        }

        setStage(p, index, "PASTE_PROMPT");
        focusGeminiComposer();
        if (!setGeminiPromptTextExact(p.prompt))
            throw new Exception("Gemini prompt box rejected the prompt");
        if (!waitForGeminiComposerContains(p.prompt, 5000L))
            throw new Exception("Prompt text could not be verified in Gemini");

        setStage(p, index, "GENERATE");
        Set<String> beforeDownloads = downloadIds();
        Set<Long> beforeMediaStore = mediaStoreDownloadIds();
        int beforeDownloadControls = countMatching(getRootInActiveWindow(), DOWNLOAD_LABELS);
        int beforeLikelyImages = countLikelyImages(getRootInActiveWindow());
        clickGenerate();

        setStage(p, index, "WAIT_GENERATION");
        waitForGeneratedDownloadControl(240000L, beforeDownloadControls, beforeLikelyImages);

        setStage(p, index, "DOWNLOAD");
        clickDownloadControl();

        long downloadId = waitForNewDownload(beforeDownloads, 60000L);
        Uri source = downloadId >= 0 ? JaxStore.findDownloadsFile(this, downloadId) : null;
        if (source == null) source = waitForNewMediaStoreDownload(beforeMediaStore, 90000L);
        if (source == null) throw new Exception("New Gemini image download was not detected");
        if (!verifyImageUri(source)) throw new Exception("Downloaded image is empty or unreadable");

        p.pendingDownloadId = downloadId;
        p.pendingSourceUri = source.toString();
        p.status = "working";
        p.stage = "OUTPUT";
        // Save the pending hand-off in the same queue record, at the exact current cursor.
        ArrayList<Prompt> latest = JaxStore.loadQueue(this);
        if (index >= 0 && index < latest.size()) latest.set(index, p);
        if (!JaxStore.saveQueue(this, latest, index))
            throw new Exception("Could not persist downloaded image checkpoint");

        saveResult(source, p, index, runId);
        p.pendingDownloadId = -1L;
        p.pendingSourceUri = "";
        p.outputName = filename(p, index);
        p.outputUri = p.outputUri == null ? "" : p.outputUri;
        p.status = "done";
        p.error = "";
        p.stage = "COMPLETED";
        latest = JaxStore.loadQueue(this);
        if (index >= 0 && index < latest.size()) latest.set(index, p);
        if (!JaxStore.saveQueue(this, latest, index + 1))
            throw new Exception("Could not persist completed output checkpoint");

        status("Done " + label(p, index));
        sleepChecked(Math.max(0, parseIntSetting("waitSec", 2)) * 1000L);
    }

    private boolean tryFinishPendingDownload(Prompt p, int index, String runId) throws Exception {
        Uri source = null;
        if (p.pendingSourceUri != null && !p.pendingSourceUri.isEmpty()) {
            try { source = Uri.parse(p.pendingSourceUri); } catch (Exception ignored) {}
        }
        if (source == null && p.pendingDownloadId >= 0)
            source = JaxStore.findDownloadsFile(this, p.pendingDownloadId);
        if (source == null) return false;
        if (outputAlreadyExistsAndValid(p, index, runId)) {
            setStage(p, index, "RECOVER_OUTPUT");
            p.pendingDownloadId = -1L;
            p.pendingSourceUri = "";
            p.outputName = filename(p, index);
            p.status = "done";
            p.stage = "COMPLETED";
            ArrayList<Prompt> existing = JaxStore.loadQueue(this);
            if (index >= 0 && index < existing.size()) existing.set(index, p);
            if (!JaxStore.saveQueue(this, existing, index + 1))
                throw new Exception("Could not persist recovered output");
            return true;
        }
        if (!verifyImageUri(source)) return false;

        setStage(p, index, "RECOVER_OUTPUT");
        saveResult(source, p, index, runId);
        p.pendingDownloadId = -1L;
        p.pendingSourceUri = "";
        p.status = "done";
        p.stage = "COMPLETED";
        ArrayList<Prompt> q = JaxStore.loadQueue(this);
        if (index >= 0 && index < q.size()) q.set(index, p);
        if (!JaxStore.saveQueue(this, q, index + 1))
            throw new Exception("Could not persist recovered output");
        return true;
    }

    private boolean outputAlreadyExistsAndValid(Prompt p,int index,String runId){
        try{
            String name=filename(p,index);
            String treeString=JaxStore.setting(this,"outputTree","");
            if(!treeString.isEmpty())return JaxStore.documentExists(this,Uri.parse(treeString),name);
            String base=JaxStore.setting(this,"folder","Jax").trim();
            if(base.isEmpty())base="Jax";
            return JaxStore.downloadsFileExists(this,sanitizeRelativePath(base)+"/"+runId,name);
        }catch(Exception e){return false;}
    }

    private void saveResult(Uri source, Prompt p, int index, String runId) throws Exception {
        String outName = filename(p, index);
        String treeString = JaxStore.setting(this, "outputTree", "");
        String outputBase = JaxStore.setting(this, "folder", "Jax").trim();
        if (outputBase.isEmpty()) outputBase = "Jax";
        outputBase = sanitizeRelativePath(outputBase);

        Uri dst;
        if (!treeString.isEmpty()) {
            Uri tree = Uri.parse(treeString);
            dst = JaxStore.copyImageAsPngToTree(this, source, tree, outName);
            if (!JaxStore.documentExists(this, tree, outName))
                throw new Exception("Output verification failed: " + outName);
        } else {
            dst = JaxStore.copyImageAsPngToDownloads(this, source,
                    outputBase + "/" + runId, outName);
            if (dst == null || !JaxStore.downloadsFileExists(this, outputBase + "/" + runId, outName))
                throw new Exception("Output filename verification failed: " + outName);
        }
        p.outputName = outName;
        p.outputUri = dst.toString();
        notifyUser("Jax saved", outName);
    }

    private String filename(Prompt p, int index) {
        String mode = JaxStore.setting(this, "naming", "exact");
        String ts = p.timestamp == null ? "" : p.timestamp.trim();
        if (ts.isEmpty()) ts = String.format(Locale.US, "%03d", index + 1);
        if (!ts.startsWith("#")) ts = "#" + ts;
        if ("safe".equals(mode)) ts = ts.replace(':','-');
        if ("numbered".equals(mode)) return String.format(Locale.US, "%03d-v1.png", index + 1);
        return ts + ".png";
    }

    private String sanitizeRelativePath(String path) {
        String[] raw = path.replace('\\','/').split("/");
        ArrayList<String> safe = new ArrayList<>();
        for (String x: raw) {
            String s = x.trim();
            if (s.isEmpty() || ".".equals(s) || "..".equals(s)) continue;
            s = s.replaceAll("[^A-Za-z0-9 _.-]", "_");
            if (!s.isEmpty()) safe.add(s);
        }
        return safe.isEmpty() ? "Jax" : join(safe,"/");
    }

    private String join(List<String> a, String sep) {
        StringBuilder b = new StringBuilder();
        for (String s:a) { if (b.length()>0) b.append(sep); b.append(s); }
        return b.toString();
    }

    private ArrayList<JaxStore.RefItem> matchedReferenceItems(Prompt p) {
        String mode = JaxStore.setting(this,"match","auto");
        ArrayList<JaxStore.RefItem> out = new ArrayList<>();
        LinkedHashSet<String> seen = new LinkedHashSet<>();
        if ("none".equals(mode)) return out;

        if ("all".equals(mode)) {
            for (String cat:new String[]{"subject","scene","style"}) {
                for (JaxStore.RefItem r:JaxStore.refs(this,cat)) {
                    if (seen.add(r.uri.toString())) out.add(r);
                    if (out.size()>=10) return out;
                }
            }
            return out;
        }

        addExactItems(out, seen, p.subjectRefs, "subject");
        addExactItems(out, seen, p.sceneRefs, "scene");
        addExactItems(out, seen, p.styleRefs, "style");

        if (p.subjectRefs.isEmpty() && p.sceneRefs.isEmpty() && p.styleRefs.isEmpty()) {
            for (String raw:p.refs) {
                String k = JaxStore.normalizeFileKey(raw);
                if (starts(k,"CHAR","SUBJECT")) addExactItems(out,seen,Collections.singletonList(raw),"subject");
                else if (starts(k,"SCENE","LOCATION")) addExactItems(out,seen,Collections.singletonList(raw),"scene");
                else if (starts(k,"STYLE")) addExactItems(out,seen,Collections.singletonList(raw),"style");
            }
        }
        return out;
    }

    private boolean starts(String v, String... prefixes) {
        for (String p:prefixes) if (v.startsWith(p)) return true;
        return false;
    }

    private void addExactItems(ArrayList<JaxStore.RefItem> out, Set<String> seen, List<String> keys, String category) {
        if (keys==null) return;
        ArrayList<JaxStore.RefItem> pool=JaxStore.refs(this,category);
        for (String key:keys) {
            String want=JaxStore.normalizeFileKey(key);
            if (want.isEmpty()) continue;
            JaxStore.RefItem hit=null;
            for (JaxStore.RefItem r:pool) {
                if (JaxStore.normalizeFileKey(r.name).equals(want)) { hit=r; break; }
            }
            if (hit==null) throw new MissingReferenceException(category+": "+key);
            if (seen.add(hit.uri.toString())) out.add(hit);
            if (out.size()>=10) return;
        }
    }

    private static final class MissingReferenceException extends RuntimeException {
        MissingReferenceException(String s){super("Missing reference "+s);}
    }

    private void validateReferenceSelection(Prompt p, ArrayList<JaxStore.RefItem> refs) throws Exception {
        int wanted=p.subjectRefs.size()+p.sceneRefs.size()+p.styleRefs.size();
        if (wanted>10) throw new Exception("Prompt requests more than 10 unique reference images");
        int explicit=p.subjectRefs.size()+p.sceneRefs.size()+p.styleRefs.size();
        if (explicit>0 && refs.size()!=Math.min(explicit,10))
            throw new Exception("Reference mapping verification failed for "+label(p,0));
    }

    private void uploadReferencesOneByOne(ArrayList<JaxStore.RefItem> refs) throws Exception {
        for (JaxStore.RefItem ref:refs) {
            checkStop();
            int before=countAttachmentControls();
            setStageOnly("ATTACH "+ref.name);

            clickAttachControl();
            sleepChecked(700L);
            selectSingleFileInPicker(ref.name);

            // Confirm only when the picker still has a confirmation action.
            sleepChecked(500L);
            if (countAttachmentControls() <= before) {
                tapText("Open|Select|Done", true, 1200L);
            }
            waitForAttachmentCount(before+1, 6000L);
        }
    }

    private void selectSingleFileInPicker(String name) throws Exception {
        String base=JaxStore.normalizeFileKey(name);
        if (tapTextExactOrParent(name, 5000L)) return;
        if (!base.equals(name) && tapTextExactOrParent(base, 3500L)) return;

        if (tapText("Search", true, 1200L)) {
            if (!setEditableTextPreferSearch(name) && !setEditableTextPreferSearch(base)) {
                // Continue with visible-name lookup.
            } else {
                sleepChecked(600L);
                if (tapTextExactOrParent(name, 4500L)) return;
                if (!base.equals(name) && tapTextExactOrParent(base, 3500L)) return;
            }
        }

        for (int i=0;i<5;i++) {
            checkStop();
            scrollActiveWindow();
            sleepChecked(350L);
            if (tapTextExactOrParent(name, 1300L)) return;
            if (!base.equals(name) && tapTextExactOrParent(base, 1000L)) return;
        }
        throw new Exception("Android file picker could not select "+name);
    }

    private boolean tapTextExactOrParent(String text, long timeout) throws Exception {
        long end=System.currentTimeMillis()+timeout;
        while(System.currentTimeMillis()<end) {
            checkStop();
            AccessibilityNodeInfo n=findBestText(getRootInActiveWindow(), text, false);
            if(n!=null) { clickNode(n); return true; }
            sleepChecked(180L);
        }
        return false;
    }

    private boolean setEditableTextPreferSearch(String s) {
        if (s==null||s.isEmpty()) return false;
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null)return false;
        ArrayList<AccessibilityNodeInfo> editables=new ArrayList<>();
        collectEditables(root,editables);
        for(AccessibilityNodeInfo e:editables) {
            String info=nodeInfo(e).toLowerCase(Locale.US);
            if(info.contains("search")||info.contains("file name")||info.contains("find"))
                if(setEditableNode(e,s))return true;
        }
        for(AccessibilityNodeInfo e:editables) if(setEditableNode(e,s))return true;
        return false;
    }

    private boolean setEditableNode(AccessibilityNodeInfo e,String s) {
        try {
            Bundle b=new Bundle();
            b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,s);
            if(e.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b))return true;
        } catch(Exception ignored) {}
        try {
            ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            if(cm==null)return false;
            cm.setPrimaryClip(ClipData.newPlainText("Jax",s));
            e.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
            return e.performAction(AccessibilityNodeInfo.ACTION_PASTE);
        } catch(Exception ignored) { return false; }
    }

    private void focusGeminiComposer() throws Exception {
        AccessibilityNodeInfo e=findGeminiComposer();
        if(e==null)throw new Exception("Gemini prompt box not found");
        try {
            e.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
            if(e.isClickable())e.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            else if(e.getParent()!=null&&e.getParent().isClickable())e.getParent().performAction(AccessibilityNodeInfo.ACTION_CLICK);
        } catch(Exception ignored) {}
        sleepChecked(250L);
    }

    private boolean setGeminiPromptTextExact(String s) {
        AccessibilityNodeInfo e=findGeminiComposer();
        if(e==null)return false;
        if(setEditableNode(e,s) && waitForGeminiComposerContainsQuiet(s,3000L))return true;
        return false;
    }

    private boolean waitForGeminiComposerContains(String s,long timeout)throws Exception {
        long end=System.currentTimeMillis()+timeout;
        String target=s==null?"":s.trim();
        String probe=target.substring(0,Math.min(100,target.length())).toLowerCase(Locale.US);
        while(System.currentTimeMillis()<end){
            checkStop();
            if(composerContains(probe))return true;
            sleepChecked(150L);
        }
        return false;
    }

    private boolean waitForGeminiComposerContainsQuiet(String s,long timeout) {
        try { return waitForGeminiComposerContains(s,timeout); }
        catch(Exception e){ return false; }
    }

    private boolean composerContains(String probe) {
        AccessibilityNodeInfo e=findGeminiComposer();
        if(e==null)return false;
        String t=e.getText()==null?"":e.getText().toString();
        String ui=normalizeForUi(t);
        String target=normalizeForUi(probe);
        if(target.isEmpty())return false;
        if(ui.contains(target))return true;
        if(target.length()>600){
            String head=target.substring(0,300);
            String tail=target.substring(target.length()-300);
            return ui.contains(head)&&ui.contains(tail);
        }
        return false;
    }

    private String normalizeForUi(String s){
        if(s==null)return "";
        return s.replace('\u00a0',' ').replaceAll("\\s+"," ").trim().toLowerCase(Locale.US);
    }

    private AccessibilityNodeInfo findGeminiComposer() {
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null)return null;
        ArrayList<AccessibilityNodeInfo> all=new ArrayList<>();
        ArrayList<AccessibilityNodeInfo> editables=new ArrayList<>();
        collectNodes(root,all);
        for(AccessibilityNodeInfo n:all) if(n.isEditable()&&n.isVisibleToUser())editables.add(n);

        AccessibilityNodeInfo best=null;
        int bestScore=Integer.MIN_VALUE;
        for(AccessibilityNodeInfo n:editables){
            String info=nodeInfo(n).toLowerCase(Locale.US);
            int score=0;
            if(info.contains("ask gemini"))score+=1400;
            if(info.contains("describe your image"))score+=1100;
            if(info.contains("type a prompt"))score+=900;
            if(info.contains("ask away"))score+=700;
            if(info.contains("search or enter address")||info.contains("enter address")||info.contains("url"))score-=1600;
            if(info.contains("search"))score-=300;
            Rect b=new Rect();n.getBoundsInScreen(b);
            if(b.width()>220)score+=120;
            if(b.height()>30)score+=30;
            if(score>bestScore){bestScore=score;best=n;}
        }
        return best;
    }

    private void clickGenerate() throws Exception {
        AccessibilityNodeInfo composer=findGeminiComposer();
        Rect composerBounds=new Rect();
        if(composer!=null)composer.getBoundsInScreen(composerBounds);
        if(composerBounds.isEmpty()) throw new Exception("Gemini composer bounds unavailable");

        AccessibilityNodeInfo n=findGenerateNode(composerBounds);
        if(n!=null){
            clickNode(n);
            if(waitForGenerateStart(composerBounds,12000L)) return;
        }

        // Gemini/Quetta's blue send arrow can be exposed as an unlabeled WebView
        // control. In that case AccessibilityNodeInfo may not contain a usable
        // clickable node even though the arrow is visibly tappable. Use a
        // coordinate gesture at the standard composer send-button location.
        checkStop();
        float x=Math.max(composerBounds.left+40, composerBounds.right-24);
        float y=Math.max(composerBounds.top+24, composerBounds.bottom-24);
        if(!tapScreen(x,y)) throw new Exception("Gemini Generate/Send button could not be tapped");
        if(waitForGenerateStart(composerBounds,12000L)) return;

        throw new Exception("Generate/Send tap was not confirmed by Gemini");
    }

    private boolean tapScreen(float x,float y) throws Exception {
        if(Build.VERSION.SDK_INT < 24) return false;
        Path path=new Path();
        path.moveTo(x,y);
        GestureDescription.StrokeDescription stroke=
                new GestureDescription.StrokeDescription(path,0,70);
        GestureDescription gesture=new GestureDescription.Builder()
                .addStroke(stroke).build();
        return dispatchGesture(gesture,null,null);
    }

    private boolean waitForGenerateStart(Rect composerBounds,long timeout)throws Exception {
        long end=System.currentTimeMillis()+timeout;
        while(System.currentTimeMillis()<end){
            checkStop();
            AccessibilityNodeInfo root=getRootInActiveWindow();
            String treeText=windowText(root).toLowerCase(Locale.US);
            if(treeText.contains("generating") || treeText.contains("stop generating") ||
               treeText.contains("working") || treeText.contains("creating image") ||
               treeText.contains("creating")) return true;

            AccessibilityNodeInfo composer=findGeminiComposer();
            boolean stillHasPrompt=false;
            if(composer!=null){
                String t=composer.getText()==null?"":composer.getText().toString().trim();
                stillHasPrompt=t.length()>0;
                if(!stillHasPrompt) return true;
            }

            AccessibilityNodeInfo send=findGenerateNode(composerBounds);
            if(send==null && !stillHasPrompt) return true;
            sleepChecked(220L);
        }
        return false;
    }

    private AccessibilityNodeInfo findGenerateNode(Rect composerBounds) {
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null)return null;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();
        collectNodes(root,nodes);
        AccessibilityNodeInfo best=null;
        int bestScore=Integer.MIN_VALUE;
        for(AccessibilityNodeInfo n:nodes){
            if(!n.isVisibleToUser() || !n.isClickable())continue;
            String all=nodeInfo(n).toLowerCase(Locale.US);
            String viewId=viewId(n).toLowerCase(Locale.US);
            String cls=className(n).toLowerCase(Locale.US);
            int labelScore=labelScore(all,GENERATE_LABELS);
            if(labelScore<0 && !viewId.contains("send") && !viewId.contains("submit") && !viewId.contains("generate"))continue;
            int score=Math.max(0,labelScore);
            if(viewId.contains("send")||viewId.contains("generate"))score+=500;
            if(cls.contains("button")||cls.contains("imagebutton"))score+=250;
            Rect b=new Rect();n.getBoundsInScreen(b);
            if(composerBounds!=null&&!composerBounds.isEmpty()){
                if(b.centerY()>=composerBounds.top-160 && b.centerY()<=composerBounds.bottom+180)score+=350;
                if(b.centerX()>=composerBounds.centerX())score+=150;
                if(b.right>=composerBounds.right-220)score+=100;
            }
            if(b.width()>25&&b.height()>20)score+=30;
            if(score>bestScore){bestScore=score;best=n;}
        }
        if(best!=null && bestScore>0)return best;

        // Fallback for unlabeled Gemini arrow/send buttons: choose the rightmost
        // clickable control inside the composer action area. This is intentionally
        // spatial rather than text-based because the arrow often has no label.
        if(composerBounds!=null&&!composerBounds.isEmpty()){
            AccessibilityNodeInfo fallback=findComposerSideButton(root,composerBounds,true);
            if(fallback!=null)return fallback;
        }
        return null;
    }

    private void clickAttachControl() throws Exception {
        AccessibilityNodeInfo composer=findGeminiComposer();
        Rect bounds=new Rect(); if(composer!=null)composer.getBoundsInScreen(bounds);
        long end=System.currentTimeMillis()+8000L;
        while(System.currentTimeMillis()<end){
            checkStop();
            AccessibilityNodeInfo n=findAttachNode(bounds);
            if(n!=null){clickNode(n);return;}
            if(bounds!=null&&!bounds.isEmpty()){
                AccessibilityNodeInfo fallback=findComposerSideButton(getRootInActiveWindow(),bounds,false);
                if(fallback!=null){clickNode(fallback);return;}
            }
            sleepChecked(220L);
        }
        throw new Exception("Gemini attachment button not found");
    }

    private AccessibilityNodeInfo findAttachNode(Rect composerBounds) {
        return findControlNear(getRootInActiveWindow(),ATTACH_LABELS,composerBounds,false);
    }

    private void clickDownloadControl() throws Exception {
        AccessibilityNodeInfo root=getRootInActiveWindow();
        AccessibilityNodeInfo n=findControlNear(root,DOWNLOAD_LABELS,findLargestLikelyImageBounds(root),true);
        if(n==null){
            Rect imageBounds=findLargestLikelyImageBounds(root);
            if(imageBounds!=null){
                AccessibilityNodeInfo more=findControlNear(root,MORE_LABELS,imageBounds,false);
                if(more!=null){
                    clickNode(more);
                    sleepChecked(450L);
                    n=findControlNear(getRootInActiveWindow(),DOWNLOAD_LABELS,imageBounds,true);
                }
            }
        }
        if(n==null)throw new Exception("Generated image Download control not found");
        clickNode(n);
        sleepChecked(1200L);
    }

    private void waitForGeneratedDownloadControl(long timeout,int beforeDownloadControls,int beforeLikelyImages) throws Exception {
        long end=System.currentTimeMillis()+timeout;
        int scrolls=0;
        while(System.currentTimeMillis()<end){
            checkStop();
            AccessibilityNodeInfo root=getRootInActiveWindow();
            int downloads=countMatching(root,DOWNLOAD_LABELS);
            int images=countLikelyImages(root);
            if((downloads>beforeDownloadControls || images>beforeLikelyImages) &&
                    (findControlNear(root,DOWNLOAD_LABELS,findLargestLikelyImageBounds(root),true)!=null ||
                     findControlNear(root,MORE_LABELS,findLargestLikelyImageBounds(root),false)!=null))return;
            if(scrolls<30){scrollActiveWindow();scrolls++;}
            sleepChecked(1000L);
        }
        throw new Exception("Timed out waiting for generated Gemini image");
    }

    private AccessibilityNodeInfo findComposerSideButton(AccessibilityNodeInfo root,Rect composerBounds,boolean rightSide){
        if(root==null||composerBounds==null||composerBounds.isEmpty())return null;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>(); collectNodes(root,nodes);
        AccessibilityNodeInfo best=null; int bestScore=Integer.MIN_VALUE;
        for(AccessibilityNodeInfo n:nodes){
            if(!n.isVisibleToUser()||!n.isClickable())continue;
            Rect b=new Rect(); n.getBoundsInScreen(b);
            int dy=Math.abs(b.centerY()-composerBounds.centerY());
            if(dy>120)continue;
            if(rightSide){
                if(b.centerX()<composerBounds.centerX())continue;
                if(b.left<composerBounds.left-30 || b.right>composerBounds.right+80)continue;
                int score=b.centerX()+Math.max(0,220-dy*2);
                String info=nodeInfo(n).toLowerCase(Locale.US);
                if(info.contains("microphone")||info.contains("voice"))score-=450;
                if(info.contains("send")||info.contains("generate"))score+=700;
                if(score>bestScore){bestScore=score;best=n;}
            }else{
                if(b.centerX()>composerBounds.centerX())continue;
                if(b.left<composerBounds.left-80 || b.right>composerBounds.centerX()+40)continue;
                int score=(composerBounds.left+40)-b.centerX()+Math.max(0,220-dy*2);
                String info=nodeInfo(n).toLowerCase(Locale.US);
                if(info.contains("microphone")||info.contains("voice"))score-=450;
                if(info.contains("add")||info.contains("attach")||info.contains("upload"))score+=700;
                if(score>bestScore){bestScore=score;best=n;}
            }
        }
        return bestScore>0?best:null;
    }


    private AccessibilityNodeInfo findControlNear(AccessibilityNodeInfo root,String[] labels,Rect referenceBounds,boolean preferHighContent) {
        if(root==null)return null;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>(); collectNodes(root,nodes);
        AccessibilityNodeInfo best=null; int bestScore=Integer.MIN_VALUE;
        for(AccessibilityNodeInfo n:nodes){
            if(!n.isVisibleToUser())continue;
            String all=nodeInfo(n).toLowerCase(Locale.US);
            String id=viewId(n).toLowerCase(Locale.US);
            int score=labelScore(all,labels);
            if(score<0&&!id.contains("download")&&!id.contains("attach")&&!id.contains("file")&&!id.contains("upload"))continue;
            if(score<0)score=0;
            if(n.isClickable())score+=250;
            if(className(n).toLowerCase(Locale.US).contains("button"))score+=150;
            if(id.contains("download"))score+=350;
            if(preferHighContent&&all.contains("download"))score+=70;
            Rect b=new Rect();n.getBoundsInScreen(b);
            if(referenceBounds!=null&&!referenceBounds.isEmpty()){
                int dy=Math.abs(b.centerY()-referenceBounds.centerY());
                score+=Math.max(0,260-dy/2);
            }
            if(b.width()>25&&b.height()>20)score+=20;
            if(score>bestScore){bestScore=score;best=n;}
        }
        return best;
    }

    private int labelScore(String all,String[] labels) {
        int best=-1;
        for(int i=0;i<labels.length;i++){
            String x=labels[i].toLowerCase(Locale.US);
            if(all.contains(x))best=Math.max(best,1000-i*60);
        }
        return best;
    }

    private void clearChatAttachments() throws Exception {
        for(int i=0;i<16;i++){
            AccessibilityNodeInfo n=findControlNear(getRootInActiveWindow(),REMOVE_LABELS,null,false);
            if(n==null)break;
            clickNode(n); sleepChecked(220L);
        }
    }

    private int countAttachmentControls(){return countMatching(getRootInActiveWindow(),REMOVE_LABELS);}

    private void waitForAttachmentCount(int wanted,long timeout)throws Exception{
        long end=System.currentTimeMillis()+timeout;
        while(System.currentTimeMillis()<end){
            checkStop();
            if(countAttachmentControls()>=wanted)return;
            sleepChecked(180L);
        }
        if(wanted>0)throw new Exception("Gemini reference attachment was not verified");
    }

    private void ensureGemini(String browser)throws Exception{
        if(isOnGemini(browser)&&findGeminiComposer()!=null)return;
        Intent in=new Intent(Intent.ACTION_VIEW,Uri.parse("https://gemini.google.com/"));
        in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if(browser!=null&&!browser.trim().isEmpty())in.setPackage(browser.trim());
        try{startActivity(in);}catch(Exception ex){in.setPackage(null);startActivity(in);}
        waitForGemini(15000L,browser);
    }

    private void waitForGemini(long timeout,String browser)throws Exception{
        long end=System.currentTimeMillis()+timeout;
        while(System.currentTimeMillis()<end){
            checkStop();
            if(isOnGemini(browser)&&findGeminiComposer()!=null)return;
            sleepChecked(300L);
        }
        throw new Exception("Gemini page/composer not ready");
    }

    private boolean isOnGemini(String browser){
        String pkg=activePackage==null?"":activePackage.toLowerCase(Locale.US);
        String bp=browser==null?"":browser.toLowerCase(Locale.US);
        if(!(pkg.equals(bp)||pkg.contains("quetta")||pkg.contains("chrome")||pkg.contains("chromium")))return false;
        String text=windowText(getRootInActiveWindow()).toLowerCase(Locale.US);
        return text.contains("gemini") || text.contains("gemini.google.com");
    }

    private void setStage(Prompt p,int index,String stage){
        p.stage=stage;p.status="working";
        try{
            ArrayList<Prompt> q=JaxStore.loadQueue(this);
            if(index>=0&&index<q.size()){
                q.set(index,p);
                JaxStore.saveQueue(this,q,JaxStore.cursor(this));
            }
        }catch(Exception ignored){}
        status("Jax "+label(p,index)+" — "+stage);
    }
    private void setStageOnly(String stage){status("Jax — "+stage);}

    private AccessibilityNodeInfo findBestText(AccessibilityNodeInfo root,String text,boolean partial){
        if(root==null||text==null)return null;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();collectNodes(root,nodes);
        String wanted=text.trim().toLowerCase(Locale.US);
        AccessibilityNodeInfo best=null;int score=Integer.MIN_VALUE;
        for(AccessibilityNodeInfo n:nodes){
            if(!n.isVisibleToUser())continue;
            String s=nodeInfo(n).trim().toLowerCase(Locale.US);
            boolean ok=partial?s.contains(wanted):s.equals(wanted)||s.startsWith(wanted+" ")||s.endsWith(" "+wanted);
            if(!ok)continue;
            int sc=partial?300:700;
            if(n.isClickable())sc+=300;
            Rect b=new Rect();n.getBoundsInScreen(b); if(b.width()>20&&b.height()>20)sc+=20;
            if(sc>score){score=sc;best=n;}
        }
        return best;
    }

    private boolean tapText(String patterns,boolean optional,long timeout)throws Exception{
        long end=System.currentTimeMillis()+timeout;
        String[] ps=patterns.split("\\|");
        while(System.currentTimeMillis()<end){
            checkStop();
            AccessibilityNodeInfo n=findClickableMatching(getRootInActiveWindow(),ps);
            if(n!=null){clickNode(n);return true;}
            sleepChecked(180L);
        }
        if(optional)return false;
        throw new Exception("UI control not found: "+patterns);
    }

    private AccessibilityNodeInfo findClickableMatching(AccessibilityNodeInfo root,String[] patterns){
        return findControlNear(root,patterns,null,false);
    }

    private void clickNode(AccessibilityNodeInfo n)throws Exception{
        if(n==null)throw new Exception("UI control missing");
        if(n.isClickable()){
            if(n.performAction(AccessibilityNodeInfo.ACTION_CLICK))return;
        }
        AccessibilityNodeInfo p=n.getParent();
        if(p!=null&&p.isClickable()&&p.performAction(AccessibilityNodeInfo.ACTION_CLICK))return;
        Rect b=new Rect();n.getBoundsInScreen(b);
        if(!b.isEmpty()&&dispatchTap(b.centerX(),b.centerY()))return;
        throw new Exception("UI control is not clickable");
    }

    private boolean dispatchTap(float x,float y){
        if(Build.VERSION.SDK_INT<24)return false;
        return dispatchTapPath(x,y);
    }

    private boolean dispatchTapPath(float x,float y){
        try{
            android.graphics.Path path=new android.graphics.Path();
            path.moveTo(x,y);
            android.accessibilityservice.GestureDescription.StrokeDescription stroke=
                    new android.accessibilityservice.GestureDescription.StrokeDescription(path,0,60);
            android.accessibilityservice.GestureDescription gesture=
                    new android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build();
            return dispatchGesture(gesture,null,null);
        }catch(Exception e){return false;}
    }

    private void collectNodes(AccessibilityNodeInfo root,List<AccessibilityNodeInfo> out){
        if(root==null)return;
        ArrayList<AccessibilityNodeInfo> stack=new ArrayList<>();stack.add(root);
        while(!stack.isEmpty()){
            AccessibilityNodeInfo n=stack.remove(stack.size()-1);
            if(n==null)continue;
            out.add(n);
            for(int i=0;i<n.getChildCount();i++){
                AccessibilityNodeInfo c=n.getChild(i);if(c!=null)stack.add(c);
            }
        }
    }
    private void collectEditables(AccessibilityNodeInfo root,List<AccessibilityNodeInfo> out){
        ArrayList<AccessibilityNodeInfo> all=new ArrayList<>();collectNodes(root,all);
        for(AccessibilityNodeInfo n:all)if(n.isVisibleToUser()&&n.isEditable())out.add(n);
    }

    private int countLikelyImages(AccessibilityNodeInfo root){
        if(root==null)return 0;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>(); collectNodes(root,nodes);
        int count=0;
        for(AccessibilityNodeInfo n:nodes){
            if(!n.isVisibleToUser())continue;
            Rect b=new Rect(); n.getBoundsInScreen(b);
            String cls=className(n).toLowerCase(Locale.US);
            if((cls.contains("imageview")||cls.contains("image")) && b.width()>180 && b.height()>120)count++;
        }
        return count;
    }

    private Rect findLargestLikelyImageBounds(AccessibilityNodeInfo root){
        if(root==null)return null;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>(); collectNodes(root,nodes);
        Rect best=null; long bestArea=0;
        for(AccessibilityNodeInfo n:nodes){
            if(!n.isVisibleToUser())continue;
            String cls=className(n).toLowerCase(Locale.US);
            if(!(cls.contains("imageview")||cls.contains("image")))continue;
            Rect b=new Rect(); n.getBoundsInScreen(b);
            long area=(long)Math.max(0,b.width())*Math.max(0,b.height());
            if(b.width()>180&&b.height()>120&&area>bestArea){bestArea=area;best=b;}
        }
        return best;
    }

    private int countMatching(AccessibilityNodeInfo root,String[] patterns){
        if(root==null)return 0;int count=0;ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();collectNodes(root,nodes);
        for(AccessibilityNodeInfo n:nodes){
            if(!n.isVisibleToUser())continue;
            String all=nodeInfo(n).toLowerCase(Locale.US);
            for(String p:patterns)if(all.contains(p.toLowerCase(Locale.US))){count++;break;}
        }
        return count;
    }

    private void scrollActiveWindow(){
        AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();collectNodes(root,nodes);
        for(AccessibilityNodeInfo n:nodes){
            if(n.isVisibleToUser()&&n.isScrollable()){
                try{if(n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD))return;}catch(Exception ignored){}
            }
        }
    }

    private String windowText(AccessibilityNodeInfo root){
        if(root==null)return "";
        StringBuilder out=new StringBuilder();
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();
        collectNodes(root,nodes);
        for(AccessibilityNodeInfo n:nodes){
            String v=nodeInfo(n);
            if(!v.isEmpty()){if(out.length()>0)out.append(' ');out.append(v);}
            if(out.length()>30000)break;
        }
        return out.toString();
    }

    private String nodeInfo(AccessibilityNodeInfo n){
        if(n==null)return "";
        String t=n.getText()==null?"":n.getText().toString();
        String cd=n.getContentDescription()==null?"":n.getContentDescription().toString();
        String hint="";
        try{if(Build.VERSION.SDK_INT>=26&&n.getHintText()!=null)hint=n.getHintText().toString();}catch(Exception ignored){}
        return t+" "+cd+" "+hint;
    }
    private String viewId(AccessibilityNodeInfo n){
        try{String s=n.getViewIdResourceName();return s==null?"":s;}catch(Exception e){return "";}
    }
    private String className(AccessibilityNodeInfo n){return n.getClassName()==null?"":n.getClassName().toString();}

    private Set<String> downloadIds(){
        Set<String> set=new HashSet<>();
        android.app.DownloadManager dm=(android.app.DownloadManager)getSystemService(DOWNLOAD_SERVICE);
        if(dm==null)return set;
        android.database.Cursor c=null;
        try{
            c=dm.query(new android.app.DownloadManager.Query().setFilterByStatus(android.app.DownloadManager.STATUS_SUCCESSFUL));
            while(c!=null&&c.moveToNext()){
                int col=c.getColumnIndex(android.app.DownloadManager.COLUMN_ID);
                if(col>=0)set.add(c.getString(col));
            }
        }catch(Exception ignored){}finally{if(c!=null)c.close();}
        return set;
    }

    private long waitForNewDownload(Set<String> before,long timeout)throws Exception{
        long end=System.currentTimeMillis()+timeout;
        android.app.DownloadManager dm=(android.app.DownloadManager)getSystemService(DOWNLOAD_SERVICE);
        if(dm==null)return -1L;
        while(System.currentTimeMillis()<end){
            checkStop();
            android.database.Cursor c=null;
            try{
                c=dm.query(new android.app.DownloadManager.Query().setFilterByStatus(android.app.DownloadManager.STATUS_SUCCESSFUL));
                while(c!=null&&c.moveToNext()){
                    int col=c.getColumnIndex(android.app.DownloadManager.COLUMN_ID);
                    if(col<0)continue;
                    String id=c.getString(col);
                    if(!before.contains(id))return Long.parseLong(id);
                }
            }catch(Exception ignored){}finally{if(c!=null)c.close();}
            sleepChecked(1000L);
        }
        return -1L;
    }

    private Set<Long> mediaStoreDownloadIds(){
        Set<Long> out=new HashSet<>();
        if(Build.VERSION.SDK_INT<29)return out;
        android.database.Cursor c=null;
        try{
            c=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.MediaColumns._ID},null,null,null);
            while(c!=null&&c.moveToNext())out.add(c.getLong(0));
        }catch(Exception ignored){}finally{if(c!=null)c.close();}
        return out;
    }

    private Uri waitForNewMediaStoreDownload(Set<Long> before,long timeout)throws Exception{
        if(Build.VERSION.SDK_INT<29)return null;
        long end=System.currentTimeMillis()+timeout;
        while(System.currentTimeMillis()<end){
            checkStop();
            android.database.Cursor c=null;
            try{
                c=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        new String[]{MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME,
                                MediaStore.MediaColumns.DATE_ADDED,MediaStore.MediaColumns.IS_PENDING},
                        null,null,MediaStore.MediaColumns.DATE_ADDED+" DESC");
                if(c!=null&&c.moveToFirst()){
                    int idCol=c.getColumnIndex(MediaStore.MediaColumns._ID);
                    int nameCol=c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME);
                    int pendingCol=c.getColumnIndex(MediaStore.MediaColumns.IS_PENDING);
                    long id=c.getLong(idCol);
                    String name=nameCol>=0?c.getString(nameCol):"";
                    long pending=pendingCol>=0?c.getLong(pendingCol):0L;
                    if(!before.contains(id)&&pending==0L&&isImageName(name))
                        return Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI,String.valueOf(id));
                }
            }catch(Exception ignored){}finally{if(c!=null)c.close();}
            sleepChecked(1200L);
        }
        return null;
    }

    private boolean isImageName(String n){
        if(n==null)return false;String x=n.toLowerCase(Locale.US);
        return x.endsWith(".png")||x.endsWith(".jpg")||x.endsWith(".jpeg")||x.endsWith(".webp");
    }
    private boolean verifyImageUri(Uri u){
        if(u==null)return false;
        try(InputStream in=getContentResolver().openInputStream(u)){
            if(in==null)return false;
            byte[] b=new byte[32];int n=in.read(b);
            return n>0;
        }catch(Exception e){return false;}
    }

    private boolean outputStillValid(Prompt p){
        try{
            if(p.outputUri!=null&&!p.outputUri.isEmpty()){
                Uri u=Uri.parse(p.outputUri);
                if(verifyImageUri(u))return true;
            }
            if(p.outputName!=null&&!p.outputName.isEmpty()){
                String tree=JaxStore.setting(this,"outputTree","");
                if(!tree.isEmpty())return JaxStore.documentExists(this,Uri.parse(tree),p.outputName);
            }
        }catch(Exception ignored){}
        return false;
    }

    private void sleepChecked(long ms)throws Exception{
        checkStop();
        try{Thread.sleep(ms);}catch(InterruptedException e){
            Thread.currentThread().interrupt();
            if(stopRequested)throw new StopRequestedException();
            throw new Exception("Jax worker interrupted");
        }
    }

    private void status(String s){try{notifyUser("Jax",s);}catch(Exception ignored){}}
    private void notifyUser(String title,String msg){
        android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(nm==null)return;
        if(Build.VERSION.SDK_INT>=26){
            android.app.NotificationChannel ch=new android.app.NotificationChannel("jax","Jax",android.app.NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
        android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26
                ?new android.app.Notification.Builder(this,"jax")
                :new android.app.Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_menu_gallery).setContentTitle(title).setContentText(msg).setAutoCancel(true);
        nm.notify(40,b.build());
    }
    private String label(Prompt p,int i){return p.timestamp==null||p.timestamp.isEmpty()?"scene "+(i+1):p.timestamp;}
    private int parseIntSetting(String key,int def){try{return Integer.parseInt(JaxStore.setting(this,key,String.valueOf(def)));}catch(Exception e){return def;}}
    private String trimError(String s){if(s==null)return "Unexpected error";s=s.replace('\n',' ');return s.length()>220?s.substring(0,220):s;}

    static class Toasts{
        static void show(Context c,String s){android.widget.Toast.makeText(c,s,android.widget.Toast.LENGTH_SHORT).show();}
    }
}
