package com.jax.gemini;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;

import java.io.*;
import java.util.*;

/** Main control panel. Keeps the original three-step workflow and adds strict validation. */
public class MainActivity extends Activity {
    private static final int REQ_PROMPT=101, REQ_REF=102, REQ_TREE=103, REQ_READ=104;
    private int refCategory=0;
    private LinearLayout root, queueBox;
    private TextView status, count;
    private EditText paste;
    private ArrayList<Prompt> prompts=new ArrayList<>();
    private final String[] cats={"subject","scene","style"};
    private final String[] catNames={"SUBJECT","SCENE","STYLE"};

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        build();
        refresh();
    }

    private TextView tv(String s,int sp){
        TextView t=new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp); t.setPadding(4,4,4,4);
        return t;
    }

    private Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b;
    }

    private LinearLayout card(){
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setPadding(14,12,14,12);
        l.setBackgroundColor(Color.rgb(23,23,28));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,8,0,0); l.setLayoutParams(p);
        return l;
    }

    private void build(){
        ScrollView sv=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(12,12,12,12);
        root.setBackgroundColor(Color.rgb(13,13,16)); sv.addView(root); setContentView(sv);

        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand=tv("Jax Gemini Automator ✦",20); brand.setTypeface(null,1);
        head.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        Button set=btn("⚙"); head.addView(set,new LinearLayout.LayoutParams(54,54)); root.addView(head); set.setOnClickListener(v->settings());

        status=tv("● Accessibility Service: checking…",12); status.setTextColor(Color.LTGRAY); root.addView(status);

        LinearLayout gem=card(); gem.addView(tv("STEP 1 — Gemini",15));
        gem.addView(tv("Open your Quetta/Gemini session. Jax starts only after Accessibility Service is enabled.",11));
        Button access=btn("Open Android Accessibility Settings"); gem.addView(access);
        access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        Button open=btn("Open Gemini in Quetta"); gem.addView(open);
        open.setOnClickListener(v->openGemini()); root.addView(gem);

        LinearLayout r=card(); r.addView(tv("STEP 2 — Reference Images",15));
        for(int i=0;i<3;i++){
            final int k=i;
            TextView h=tv(catNames[i]+"  (up to 100)",12); h.setTextColor(Color.LTGRAY); r.addView(h);
            Button b=btn("Add "+catNames[i]+" references"); r.addView(b);
            TextView n=tv("0 files",10); n.setTag("refcount"+i); r.addView(n);
            b.setOnClickListener(v->chooseReferences(k));
        }
        Button lib=btn("Prepare references for Android file picker"); r.addView(lib); lib.setOnClickListener(v->prepareRefs());
        root.addView(r);

        LinearLayout q=card(); LinearLayout qh=new LinearLayout(this);
        count=tv("Prompts 0",15); qh.addView(count,new LinearLayout.LayoutParams(0,-2,1));
        Button clear=btn("Clear"); qh.addView(clear); q.addView(qh);
        clear.setOnClickListener(v->{
            if(JaxAccessibilityService.isRunning()) { Toast.makeText(this,"Stop Jax before clearing the queue.",Toast.LENGTH_LONG).show(); return; }
            prompts.clear(); JaxStore.saveQueue(this,prompts,0); JaxStore.saveSettings(this,"runId",""); refresh();
            Toast.makeText(this,"Queue cleared",Toast.LENGTH_SHORT).show();
        });

        LinearLayout ptab=new LinearLayout(this);
        Button upload=btn("Upload Prompt File"), pasteTab=btn("Paste Text");
        ptab.addView(upload,new LinearLayout.LayoutParams(0,-2,1)); ptab.addView(pasteTab,new LinearLayout.LayoutParams(0,-2,1)); q.addView(ptab);
        upload.setOnClickListener(v->choosePromptFile());
        pasteTab.setOnClickListener(v->{ if(paste!=null){paste.requestFocus(); android.view.inputmethod.InputMethodManager im=(android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE); if(im!=null)im.showSoftInput(paste,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);} });

        paste=new EditText(this);
        paste.setHint("#00:00\n\nSUBJECT:\nCHAR_01\nSCENE:\nSCENE_01\nSTYLE:\nSTYLE_01\n\nFINAL IMAGE PROMPT:\n...");
        paste.setTextColor(Color.WHITE); paste.setHintTextColor(Color.GRAY); paste.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        paste.setMinLines(8); q.addView(paste);
        Button load=btn("Load pasted prompts into queue"); q.addView(load); load.setOnClickListener(v->loadPastedQueue());

        queueBox=new LinearLayout(this); queueBox.setOrientation(LinearLayout.VERTICAL); q.addView(queueBox); root.addView(q);

        LinearLayout run=card(); run.addView(tv("STEP 3 — Batch",15));
        Button start=btn("START JAX BATCH"), stop=btn("STOP"); run.addView(start); run.addView(stop);
        start.setOnClickListener(v->startBatch());
        stop.setOnClickListener(v->JaxAccessibilityService.stopBatch(this));
        root.addView(run);

        LinearLayout tip=card(); tip.addView(tv("What Jax does",15));
        tip.addView(tv("Reads one job → validates exact references → opens Gemini → attaches references → verifies the prompt → Generate → waits for the new result → Download → verifies the new image → saves the exact timestamp filename → marks the job complete → continues. Any failed job pauses; it is never skipped.",11));
        root.addView(tip);
    }

    private void openGemini(){
        Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://gemini.google.com/"));
        String pkg=JaxStore.setting(this,"browserPackage","net.quetta.browser").trim(); if(!pkg.isEmpty())i.setPackage(pkg); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try{startActivity(i);}catch(Exception e){i.setPackage(null); try{startActivity(i);}catch(Exception ex){Toast.makeText(this,"Could not open Gemini",Toast.LENGTH_LONG).show();}}
    }

    private void choosePromptFile(){
        Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT); in.setType("*/*");
        in.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/plain","text/*","application/json"});
        in.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(in,REQ_PROMPT);
    }

    private void chooseReferences(int category){
        refCategory=category;
        Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT); in.setType("image/*");
        in.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true); in.addCategory(Intent.CATEGORY_OPENABLE);
        in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(in,REQ_REF);
    }

    private void loadPastedQueue(){
        String text=paste==null?"":paste.getText().toString();
        ArrayList<Prompt> parsed=new ArrayList<>(PromptParser.parse(text));
        if(parsed.isEmpty()){Toast.makeText(this,"No prompts were detected",Toast.LENGTH_LONG).show();return;}
        String issue=validateParsedShape(parsed);
        if(!issue.isEmpty()){Toast.makeText(this,issue,Toast.LENGTH_LONG).show();return;}
        if(!JaxStore.saveQueue(this,parsed,0) || !JaxStore.saveSettings(this,"runId","")){
            Toast.makeText(this,"Could not save the new queue. Nothing was started.",Toast.LENGTH_LONG).show();
            return;
        }
        prompts=parsed; refresh();
        Toast.makeText(this,prompts.size()+" prompts loaded",Toast.LENGTH_SHORT).show();
    }

    private String validateParsedShape(List<Prompt> list){
        if(list.size()>100)return "Maximum batch size is 100 prompts.";
        Set<String> timestamps=new HashSet<>();
        for(int i=0;i<list.size();i++){
            Prompt p=list.get(i);
            if(p.prompt==null||p.prompt.trim().isEmpty())return "Prompt "+(i+1)+" has no FINAL IMAGE PROMPT.";
            if(p.timestamp==null||p.timestamp.trim().isEmpty())return "Prompt "+(i+1)+" has no timestamp (#HH:MM).";
            String ts=p.timestamp.trim().toUpperCase(Locale.US); if(!timestamps.add(ts))return "Duplicate timestamp: "+p.timestamp;
        }
        return "";
    }

    private void startBatch(){
        prompts=JaxStore.loadQueue(this);
        String issue=validateQueueForStart();
        if(!issue.isEmpty()){Toast.makeText(this,issue,Toast.LENGTH_LONG).show();return;}
        if(!JaxAccessibilityService.enabled(this)){
            Toast.makeText(this,"Enable Jax Accessibility Service first.",Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return;
        }
        if (needsReadPermission()) {
            requestReadPermission();
            return;
        }
        JaxAccessibilityService.startBatch(this); Toast.makeText(this,"Jax batch started / resumed",Toast.LENGTH_SHORT).show();
    }

    private boolean needsReadPermission(){
        if(Build.VERSION.SDK_INT>=33) return checkSelfPermission("android.permission.READ_MEDIA_IMAGES")!=getPackageManager().PERMISSION_GRANTED;
        if(Build.VERSION.SDK_INT>=26) return checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE")!=getPackageManager().PERMISSION_GRANTED;
        return false;
    }

    private void requestReadPermission(){
        if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{"android.permission.READ_MEDIA_IMAGES"},REQ_READ);
        else if(Build.VERSION.SDK_INT>=23) requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"},REQ_READ);
    }

    private String validateQueueForStart(){
        if(prompts.isEmpty())prompts=JaxStore.loadQueue(this);
        String shape=validateParsedShape(prompts); if(!shape.isEmpty())return shape;
        String libraryIssue=validateReferenceLibrary(); if(!libraryIssue.isEmpty())return libraryIssue;
        for(Prompt p:prompts){
            String missing=findMissingRef(p); if(!missing.isEmpty())return p.timestamp+" missing reference: "+missing;
        }
        return "";
    }

    private String validateReferenceLibrary(){
        HashSet<String> names=new HashSet<>();
        for(String cat:cats){
            ArrayList<JaxStore.RefItem> list=JaxStore.refs(this,cat);
            if(list.size()>100)return catNames[Arrays.asList(cats).indexOf(cat)]+" has more than 100 references.";
            for(JaxStore.RefItem r:list){
                String k=JaxStore.normalizeFileKey(r.name);
                if(k.isEmpty())return "Invalid reference filename in "+cat+".";
                if(!names.add(k))return "Duplicate reference filename across SUBJECT/SCENE/STYLE: "+r.name;
            }
        }
        return "";
    }

    private String findMissingRef(Prompt p){
        if(p==null)return "";
        String[] categories={"subject","scene","style"};
        @SuppressWarnings("unchecked") List<String>[] groups=new ArrayList[]{p.subjectRefs,p.sceneRefs,p.styleRefs};
        if(groups[0].isEmpty()&&groups[1].isEmpty()&&groups[2].isEmpty()){
            for(String raw:p.refs){
                String k=JaxStore.normalizeFileKey(raw); String cat=null;
                if(k.startsWith("CHAR")||k.startsWith("SUBJECT"))cat="subject";
                else if(k.startsWith("SCENE")||k.startsWith("LOCATION"))cat="scene";
                else if(k.startsWith("STYLE"))cat="style";
                if(cat!=null&&!refExists(cat,raw))return raw;
            }
            return "";
        }
        for(int i=0;i<3;i++)for(String key:groups[i])if(!refExists(categories[i],key))return key;
        return "";
    }

    private boolean refExists(String category,String key){
        String wanted=JaxStore.normalizeFileKey(key); if(wanted.isEmpty())return false;
        for(JaxStore.RefItem r:JaxStore.refs(this,category))if(JaxStore.normalizeFileKey(r.name).equals(wanted))return true;
        return false;
    }

    private void refresh(){
        if(root==null)return; prompts=JaxStore.loadQueue(this);
        if(count!=null)count.setText("Prompts "+prompts.size()+" • cursor "+Math.min(JaxStore.cursor(this),prompts.size())+"/"+prompts.size());
        if(queueBox!=null){
            queueBox.removeAllViews(); int shown=Math.min(prompts.size(),150);
            for(int i=0;i<shown;i++){
                Prompt p=prompts.get(i);
                String s=(p.timestamp==null||p.timestamp.isEmpty()?String.format(Locale.US,"%03d",i+1):p.timestamp)+"   "+p.status+(p.stage.isEmpty()?"":"   ["+p.stage+"]")+(p.error.isEmpty()?"":"   "+p.error);
                queueBox.addView(tv(s,10));
            }
        }
        for(int i=0;i<3;i++){View v=root.findViewWithTag("refcount"+i); if(v instanceof TextView)((TextView)v).setText(JaxStore.refs(this,cats[i]).size()+" files");}
        if(status!=null){
            boolean on=JaxAccessibilityService.enabled(this);
            status.setText(on?"● Accessibility Service enabled":"● Accessibility Service OFF — enable it");
            status.setTextColor(on?Color.rgb(190,255,205):Color.rgb(255,180,170));
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQ_READ){
            if(grantResults.length>0 && grantResults[0]==getPackageManager().PERMISSION_GRANTED){
                JaxAccessibilityService.startBatch(this);
                Toast.makeText(this,"Jax batch started / resumed",Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this,"Storage/image read permission is required for download verification. Enable it in Android Settings.",Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override protected void onResume(){super.onResume();refresh();}

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data); if(result!=RESULT_OK||data==null)return;
        try{
            if(req==REQ_PROMPT){
                Uri u=data.getData(); if(u==null)throw new IOException("No prompt file selected");
                String s=read(u); ArrayList<Prompt> parsed=new ArrayList<>(PromptParser.parse(s));
                if(parsed.isEmpty())throw new IOException("No prompts detected");
                String issue=validateParsedShape(parsed); if(!issue.isEmpty())throw new IOException(issue);
                if(!JaxStore.saveQueue(this,parsed,0) || !JaxStore.saveSettings(this,"runId",""))
                    throw new IOException("Could not save prompt queue");
                prompts=parsed; refresh();
                Toast.makeText(this,parsed.size()+" prompts loaded",Toast.LENGTH_SHORT).show();
            } else if(req==REQ_REF){handleReferenceResult(data);} 
            else if(req==REQ_TREE){
                Uri tree=data.getData(); if(tree==null)throw new IOException("No output folder selected");
                int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try{getContentResolver().takePersistableUriPermission(tree,flags);}catch(Exception ignored){}
                JaxStore.saveSettings(this,"outputTree",tree.toString()); Toast.makeText(this,"Output folder saved",Toast.LENGTH_SHORT).show();
            }
        }catch(Exception e){Toast.makeText(this,"Error: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    private void handleReferenceResult(Intent data)throws Exception{
        ArrayList<Uri> selected=new ArrayList<>();
        if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount()&&i<100;i++)selected.add(data.getClipData().getItemAt(i).getUri());}
        else if(data.getData()!=null)selected.add(data.getData());
        if(selected.isEmpty())throw new IOException("No reference image selected");

        ArrayList<JaxStore.RefItem> list=JaxStore.refs(this,cats[refCategory]);
        int room=100-list.size(); if(selected.size()>room)throw new IOException(catNames[refCategory]+" allows up to 100 files; remaining slots: "+room);
        int added=0;
        for(Uri u:selected){
            int flags=data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION;
            if(flags!=0){try{getContentResolver().takePersistableUriPermission(u,flags);}catch(Exception ignored){}}
            String name=displayName(u); if(name.isEmpty())name="JaxRef_"+(list.size()+1)+".jpg";
            boolean dup=false; for(JaxStore.RefItem old:list)if(JaxStore.normalizeFileKey(old.name).equals(JaxStore.normalizeFileKey(name))){dup=true;break;}
            if(!dup){list.add(new JaxStore.RefItem(name,u));added++;}
        }
        if(!JaxStore.saveRefs(this,cats[refCategory],list))throw new IOException("Could not save reference library");
        refresh(); Toast.makeText(this,added+" references added",Toast.LENGTH_SHORT).show();
    }

    private String displayName(Uri u){
        Cursor c=null;
        try{c=getContentResolver().query(u,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null);if(c!=null&&c.moveToFirst()){String n=c.getString(0);if(n!=null)return n.trim();}}
        catch(Exception ignored){} finally{if(c!=null)c.close();}
        return "";
    }

    private String read(Uri u)throws Exception{
        InputStream raw=getContentResolver().openInputStream(u); if(raw==null)throw new IOException("Cannot open prompt file");
        try(BufferedReader br=new BufferedReader(new InputStreamReader(raw))){StringBuilder s=new StringBuilder();String line;while((line=br.readLine())!=null)s.append(line).append('\n');return s.toString();}
    }

    private void prepareRefs(){
        if(JaxAccessibilityService.isRunning()){Toast.makeText(this,"Stop Jax before preparing references.",Toast.LENGTH_LONG).show();return;}
        new Thread(()->{
            int ok=0,fail=0; String last="";
            for(String cat:cats)for(JaxStore.RefItem r:JaxStore.refs(this,cat)){
                try{JaxStore.copyRefToDownloads(this,r.uri,r.name);ok++;}catch(Exception e){fail++;last=e.getMessage()==null?"reference failed":e.getMessage();}
            }
            final int a=ok,b=fail;final String err=last;
            runOnUiThread(()->Toast.makeText(this,b==0?"References prepared: "+a:"Prepared "+a+"; failed "+b+": "+err,b==0?Toast.LENGTH_SHORT:Toast.LENGTH_LONG).show());
        }).start();
    }

    private void settings(){
        final Dialog d=new Dialog(this); LinearLayout l=card(); l.setPadding(20,20,20,20); l.addView(tv("Jax Settings",18));
        EditText bp=new EditText(this);bp.setHint("Quetta package (default net.quetta.browser)");bp.setText(JaxStore.setting(this,"browserPackage","net.quetta.browser"));l.addView(bp);
        EditText folder=new EditText(this);folder.setHint("Default Downloads subfolder");folder.setText(JaxStore.setting(this,"folder","Jax"));l.addView(folder);
        Button out=btn("Choose output folder");l.addView(out);out.setOnClickListener(v->{Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(in,REQ_TREE);d.dismiss();});
        Button save=btn("Save");l.addView(save);save.setOnClickListener(v->{String p=bp.getText().toString().trim();if(p.isEmpty())p="net.quetta.browser";JaxStore.saveSettings(this,"browserPackage",p);JaxStore.saveSettings(this,"folder",folder.getText().toString().trim());d.dismiss();Toast.makeText(this,"Settings saved",Toast.LENGTH_SHORT).show();});
        d.setContentView(l);Window w=d.getWindow();if(w!=null)w.setBackgroundDrawableResource(android.R.color.transparent);d.show();
    }
}
