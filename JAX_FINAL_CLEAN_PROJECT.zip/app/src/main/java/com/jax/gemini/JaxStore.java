package com.jax.gemini;

import android.content.*;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;

import java.io.*;
import java.util.*;
import org.json.*;

/** Persistent storage and verified file operations for Jax. */
public final class JaxStore {
    public static final String PREF = "JAX";
    private JaxStore() {}

    public static synchronized boolean saveQueue(Context c, List<Prompt> ps, int cursor) {
        try {
            JSONArray a = new JSONArray();
            for (Prompt p : ps) {
                JSONObject o = new JSONObject();
                o.put("timestamp", p.timestamp);
                o.put("raw", p.raw);
                o.put("prompt", p.prompt);
                o.put("negative", p.negative);
                o.put("title", p.title);
                o.put("status", p.status);
                o.put("error", p.error);
                o.put("stage", p.stage);
                o.put("refs", new JSONArray(p.refs));
                o.put("subjectRefs", new JSONArray(p.subjectRefs));
                o.put("sceneRefs", new JSONArray(p.sceneRefs));
                o.put("styleRefs", new JSONArray(p.styleRefs));
                o.put("pendingDownloadId", p.pendingDownloadId);
                o.put("pendingSourceUri", p.pendingSourceUri);
                o.put("outputName", p.outputName);
                o.put("outputUri", p.outputUri);
                a.put(o);
            }
            return c.getSharedPreferences(PREF, 0).edit()
                    .putString("queue", a.toString())
                    .putInt("cursor", Math.max(0, cursor))
                    .commit();
        } catch (Exception e) {
            return false;
        }
    }

    public static ArrayList<Prompt> loadQueue(Context c) {
        ArrayList<Prompt> out = new ArrayList<>();
        try {
            String s = c.getSharedPreferences(PREF, 0).getString("queue", "[]");
            JSONArray a = new JSONArray(s);
            for (int i=0; i<a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Prompt p = new Prompt();
                p.timestamp = o.optString("timestamp", "");
                p.raw = o.optString("raw", "");
                p.prompt = o.optString("prompt", "");
                p.negative = o.optString("negative", "");
                p.title = o.optString("title", "");
                p.status = o.optString("status", "queued");
                p.error = o.optString("error", "");
                p.stage = o.optString("stage", "");
                readArray(o.optJSONArray("refs"), p.refs);
                readArray(o.optJSONArray("subjectRefs"), p.subjectRefs);
                readArray(o.optJSONArray("sceneRefs"), p.sceneRefs);
                readArray(o.optJSONArray("styleRefs"), p.styleRefs);
                p.pendingDownloadId = o.optLong("pendingDownloadId", -1L);
                p.pendingSourceUri = o.optString("pendingSourceUri", "");
                p.outputName = o.optString("outputName", "");
                p.outputUri = o.optString("outputUri", "");
                out.add(p);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static void readArray(JSONArray a, List<String> dst) throws Exception {
        if (a == null) return;
        for (int i=0; i<a.length(); i++) {
            String v = a.optString(i, "").trim();
            if (!v.isEmpty()) dst.add(v);
        }
    }

    public static int cursor(Context c) {
        return Math.max(0, c.getSharedPreferences(PREF,0).getInt("cursor",0));
    }

    public static boolean saveSettings(Context c, String key, String val) {
        return c.getSharedPreferences(PREF,0).edit().putString(key,val).commit();
    }

    public static String setting(Context c, String key, String def) {
        return c.getSharedPreferences(PREF,0).getString(key,def);
    }

    public static ArrayList<RefItem> refs(Context c, String category) {
        ArrayList<RefItem> out = new ArrayList<>();
        try {
            String s = setting(c, "refs_"+category, "[]");
            JSONArray a = new JSONArray(s);
            for (int i=0; i<a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String name = o.optString("name", "").trim();
                String uri = o.optString("uri", "").trim();
                if (!name.isEmpty() && !uri.isEmpty()) out.add(new RefItem(name,Uri.parse(uri)));
            }
        } catch (Exception ignored) {}
        return out;
    }

    public static boolean saveRefs(Context c, String category, ArrayList<RefItem> list) {
        try {
            JSONArray a = new JSONArray();
            for (RefItem r:list) {
                JSONObject o = new JSONObject();
                o.put("name",r.name); o.put("uri",r.uri.toString()); a.put(o);
            }
            return saveSettings(c,"refs_"+category,a.toString());
        } catch (Exception e) { return false; }
    }

    public static final class RefItem {
        public final String name;
        public final Uri uri;
        public RefItem(String n, Uri u) { name=n; uri=u; }
    }

    public static String normalizeFileKey(String s) {
        if (s == null) return "";
        String n=s.trim().toUpperCase(Locale.US);
        while (n.startsWith("#")) n=n.substring(1);
        int slash=Math.max(n.lastIndexOf('/'),n.lastIndexOf('\\'));
        if (slash>=0) n=n.substring(slash+1);
        int dot=n.lastIndexOf('.');
        if(dot>0) n=n.substring(0,dot);
        return n.replaceAll("[^A-Z0-9]+","_").replaceAll("^_+|_+$","");
    }

    public static boolean copyRefToDownloads(Context c, Uri source, String fileName) throws IOException {
        if (Build.VERSION.SDK_INT < 29)
            throw new IOException("Android 10+ is required for automatic reference preparation");
        if (source == null) throw new IOException("Reference URI is missing");
        if (fileName == null || fileName.trim().isEmpty()) throw new IOException("Reference filename is missing");
        ContentResolver cr=c.getContentResolver();
        if (downloadsFileExists(c,"Jax/References",fileName)) return true;

        ContentValues v=new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME,fileName);
        v.put(MediaStore.MediaColumns.MIME_TYPE,guessMime(fileName));
        v.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Jax/References");
        v.put(MediaStore.MediaColumns.IS_PENDING,1);
        Uri dst=cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
        if(dst==null)throw new IOException("Downloads insert failed: "+fileName);
        try(InputStream in=cr.openInputStream(source); OutputStream os=cr.openOutputStream(dst)) {
            if(in==null)throw new IOException("Cannot open source reference: "+fileName);
            if(os==null)throw new IOException("Cannot open reference output: "+fileName);
            byte[] buffer=new byte[65536];
            int n; long total=0;
            while((n=in.read(buffer))>0){ os.write(buffer,0,n); total+=n; }
            if(total<=0)throw new IOException("Reference file is empty: "+fileName);
            ContentValues done=new ContentValues(); done.put(MediaStore.MediaColumns.IS_PENDING,0);
            cr.update(dst,done,null,null);
            if(!downloadsFileExists(c,"Jax/References",fileName))
                throw new IOException("Reference preparation verification failed: "+fileName);
            return true;
        } catch(Exception e) {
            cr.delete(dst,null,null);
            if(e instanceof IOException)throw (IOException)e;
            throw new IOException(e.getMessage()==null?"Reference preparation failed":e.getMessage(),e);
        }
    }

    private static String guessMime(String name) {
        String n=name.toLowerCase(Locale.US);
        if(n.endsWith(".png"))return "image/png";
        if(n.endsWith(".webp"))return "image/webp";
        if(n.endsWith(".gif"))return "image/gif";
        return "image/jpeg";
    }

    public static boolean downloadsFileExists(Context c,String relativePath,String displayName) {
        if(Build.VERSION.SDK_INT<29)return false;
        String[] proj={MediaStore.MediaColumns._ID};
        String sel=MediaStore.MediaColumns.RELATIVE_PATH+"=? AND "+MediaStore.MediaColumns.DISPLAY_NAME+"=?";
        String path=relativePath.endsWith("/")?relativePath:relativePath+"/";
        try(android.database.Cursor cur=c.getContentResolver().query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,proj,sel,new String[]{path,displayName},null)){
            return cur!=null&&cur.moveToFirst();
        }catch(Exception e){return false;}
    }

    public static Uri findDownloadsFile(Context c,long downloadId) {
        try {
            android.app.DownloadManager dm=(android.app.DownloadManager)c.getSystemService(Context.DOWNLOAD_SERVICE);
            return dm==null?null:dm.getUriForDownloadedFile(downloadId);
        } catch(Exception e){return null;}
    }

    public static Uri copyImageAsPngToTree(Context c,Uri source,Uri tree,String displayName)throws IOException {
        if(tree==null)throw new IOException("Output folder is missing");
        if(documentExists(c,tree,displayName))throw new IOException("Output file already exists: "+displayName);
        Bitmap b=decodeImage(c,source);
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
        Uri dst=DocumentsContract.createDocument(c.getContentResolver(),children,"image/png",displayName);
        if(dst==null){b.recycle();throw new IOException("Cannot create output file: "+displayName);}
        try(OutputStream out=c.getContentResolver().openOutputStream(dst)){
            if(out==null)throw new IOException("Cannot open output file: "+displayName);
            if(!b.compress(Bitmap.CompressFormat.PNG,100,out))throw new IOException("PNG conversion failed: "+displayName);
        }catch(Exception e){
            try{DocumentsContract.deleteDocument(c.getContentResolver(),dst);}catch(Exception ignored){}
            if(e instanceof IOException)throw (IOException)e;
            throw new IOException(e.getMessage()==null?"Output write failed":e.getMessage(),e);
        }finally{b.recycle();}
        return dst;
    }

    public static Uri copyImageAsPngToDownloads(Context c,Uri source,String relativePath,String displayName)throws IOException {
        if(Build.VERSION.SDK_INT<29)throw new IOException("Android 10+ is required for automatic Downloads output");
        if(downloadsFileExists(c,relativePath,displayName))throw new IOException("Output file already exists: "+displayName);
        Bitmap b=decodeImage(c,source);
        ContentValues v=new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME,displayName);
        v.put(MediaStore.MediaColumns.MIME_TYPE,"image/png");
        String path=relativePath.endsWith("/")?relativePath:relativePath+"/";
        v.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/"+path);
        v.put(MediaStore.MediaColumns.IS_PENDING,1);
        ContentResolver cr=c.getContentResolver();
        Uri dst=cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
        if(dst==null){b.recycle();throw new IOException("Could not create Downloads output: "+displayName);}
        try(OutputStream out=cr.openOutputStream(dst)){
            if(out==null)throw new IOException("Could not open Downloads output: "+displayName);
            if(!b.compress(Bitmap.CompressFormat.PNG,100,out))throw new IOException("PNG conversion failed: "+displayName);
            ContentValues done=new ContentValues(); done.put(MediaStore.MediaColumns.IS_PENDING,0);
            cr.update(dst,done,null,null);
            if(!downloadsFileExists(c,relativePath,displayName))throw new IOException("Output verification failed: "+displayName);
            return dst;
        }catch(Exception e){
            cr.delete(dst,null,null);
            if(e instanceof IOException)throw (IOException)e;
            throw new IOException(e.getMessage()==null?"Output write failed":e.getMessage(),e);
        }finally{b.recycle();}
    }

    private static Bitmap decodeImage(Context c,Uri source)throws IOException {
        if(source==null)throw new IOException("Source image is missing");
        try(InputStream in=c.getContentResolver().openInputStream(source)){
            if(in==null)throw new IOException("Cannot open source image");
            Bitmap b=BitmapFactory.decodeStream(in);
            if(b==null)throw new IOException("Downloaded file is not a readable image");
            return b;
        }catch(IOException e){throw e;}catch(Exception e){throw new IOException("Could not read image",e);}
    }

    public static boolean documentExists(Context c,Uri tree,String displayName) {
        if(tree==null||displayName==null)return false;
        try(android.database.Cursor cur=c.getContentResolver().query(
                DocumentsContract.buildChildDocumentsUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree)),
                new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},
                DocumentsContract.Document.COLUMN_DISPLAY_NAME+"=?",
                new String[]{displayName},null)){
            return cur!=null&&cur.moveToFirst();
        }catch(Exception e){return false;}
    }
}
