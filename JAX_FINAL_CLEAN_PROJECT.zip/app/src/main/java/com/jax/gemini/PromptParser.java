package com.jax.gemini;

import java.util.*;
import java.util.regex.*;
import org.json.*;

/** Parser for Jax timestamped prompt batches. */
public final class PromptParser {
    private static final Set<String> SECTIONS = new HashSet<>(Arrays.asList(
            "FINAL IMAGE PROMPT", "PROMPT", "NEGATIVE PROMPT",
            "SUBJECT", "CHARACTERS", "LOCATION", "SCENE", "STYLE",
            "OBJECTS", "REFERENCE IMAGES"
    ));

    private static final Pattern TIMESTAMP = Pattern.compile(
            "^\\s*#\\s*(\\d{1,3}:\\d{2}(?::\\d{2})?)\\s*$"
    );
    private static final Pattern SECTION_LINE = Pattern.compile(
            "^\\s*\\*{0,2}([A-Za-z][A-Za-z _-]*?)(?:\\s*:\\s*(.*?))?\\s*\\*{0,2}\\s*$"
    );
    private static final Pattern KEY_PATTERN = Pattern.compile(
            "(?:^|[\\s,;|])(?:#)?(?:CHAR(?:ACTER)?|SUBJECT|LOCATION|SCENE|STYLE|OBJECT|REF|REFERENCE)[_\\s-]?\\d+\\b",
            Pattern.CASE_INSENSITIVE
    );

    private PromptParser() {}

    public static List<Prompt> parse(String input) {
        if (input == null) return new ArrayList<>();
        String text = normalizeNewlines(input);
        String trimmed = text.trim();
        if (trimmed.isEmpty()) return new ArrayList<>();

        if (trimmed.startsWith("[") || trimmed.startsWith("{")) {
            try {
                return parseJson(trimmed);
            } catch (Exception ignored) {
                // Fall back to the plain-text parser.
            }
        }

        ArrayList<Prompt> out = new ArrayList<>();
        Prompt cur = null;
        String section = "";

        for (String line : text.split("\\n", -1)) {
            Matcher tm = TIMESTAMP.matcher(line);
            if (tm.matches()) {
                if (cur != null) finish(cur, out);
                cur = new Prompt();
                cur.timestamp = "#" + tm.group(1);
                cur.title = cur.timestamp;
                section = "";
                continue;
            }

            if (cur == null) {
                if (line.trim().isEmpty()) continue;
                cur = new Prompt();
            }

            String s = line.trim();
            if (s.isEmpty()) {
                if (!section.isEmpty() && isPromptSection(section))
                    append(cur, section, "");
                continue;
            }

            Section parsedSection = parseSectionLine(s);
            if (parsedSection != null && isSection(parsedSection.name)) {
                section = parsedSection.name;
                if (!parsedSection.inlineValue.isEmpty()) {
                    handleSectionValue(cur, section, parsedSection.inlineValue);
                }
                continue;
            }

            if ("SUBJECT".equals(section) || "CHARACTERS".equals(section) ||
                    "SCENE".equals(section) || "LOCATION".equals(section) ||
                    "STYLE".equals(section) || "REFERENCE IMAGES".equals(section)) {
                handleReferenceLine(cur, section, s);
            } else if (isPromptSection(section)) {
                append(cur, section, line);
                extractKeyRefs(cur, line, section);
            } else {
                cur.raw = appendText(cur.raw, line);
                extractKeyRefs(cur, line, section);
            }
        }

        if (cur != null) finish(cur, out);

        // If there was only an un-timestamped block, split by blank blocks only
        // when that gives an unambiguous multi-prompt input. No timestamps are invented.
        if (out.size() == 1 && out.get(0).timestamp.isEmpty()) {
            String[] blocks = text.trim().split("\\n\\s*\\n\\s*\\n+", -1);
            if (blocks.length > 1) {
                out.clear();
                for (String block : blocks) {
                    String b = block.trim();
                    if (b.isEmpty()) continue;
                    Prompt p = new Prompt();
                    p.raw = b;
                    p.prompt = b;
                    p.title = "Prompt " + (out.size() + 1);
                    p.refs.addAll(extractKeyRefs(b));
                    out.add(p);
                }
            }
        }
        return out;
    }

    private static String normalizeNewlines(String s) {
        return s.replace("\\r\\n", "\n")
                .replace("\\n", "\n")
                .replace("\\r", "\n")
                .replace("\r\n", "\n")
                .replace('\r', '\n');
    }

    private static boolean isSection(String h) { return SECTIONS.contains(h); }
    private static boolean isPromptSection(String s) {
        return "FINAL IMAGE PROMPT".equals(s) || "PROMPT".equals(s) || "NEGATIVE PROMPT".equals(s);
    }

    private static Section parseSectionLine(String s) {
        Matcher m = SECTION_LINE.matcher(s);
        if (!m.matches()) return null;
        String name = m.group(1).replace('*', ' ').trim().replaceAll("\\s+", " ")
                .replace('-', ' ').toUpperCase(Locale.US);
        String value = m.group(2) == null ? "" : m.group(2).trim();
        return new Section(name, value);
    }

    private static void handleSectionValue(Prompt p, String section, String value) {
        if (isPromptSection(section)) {
            append(p, section, value);
            extractKeyRefs(p, value, section);
        } else if ("SUBJECT".equals(section) || "CHARACTERS".equals(section) ||
                "SCENE".equals(section) || "LOCATION".equals(section) ||
                "STYLE".equals(section) || "REFERENCE IMAGES".equals(section)) {
            handleReferenceLine(p, section, value);
        }
    }

    private static void handleReferenceLine(Prompt p, String section, String value) {
        String v = value.trim();
        if (v.isEmpty()) return;
        // Allow comma/semicolon-separated IDs and normal filenames/labels.
        String[] parts = v.split("[,;|]");
        for (String part : parts) {
            String key = cleanReferenceKey(part);
            if (key.isEmpty()) continue;
            p.refs.add(key);
            if ("SUBJECT".equals(section) || "CHARACTERS".equals(section)) p.subjectRefs.add(key);
            else if ("SCENE".equals(section) || "LOCATION".equals(section)) p.sceneRefs.add(key);
            else if ("STYLE".equals(section)) p.styleRefs.add(key);
        }
    }

    private static String cleanReferenceKey(String s) {
        if (s == null) return "";
        String v = s.trim();
        v = v.replaceFirst("^[-*•]+\\s*", "");
        v = v.replaceAll("^\\\"|\\\"$", "");
        if (v.endsWith(":")) v = v.substring(0, v.length()-1).trim();
        return v;
    }

    private static void append(Prompt p, String section, String line) {
        if ("NEGATIVE PROMPT".equals(section)) p.negative = appendText(p.negative, line);
        else p.prompt = appendText(p.prompt, line);
        p.raw = appendText(p.raw, line);
    }

    private static String appendText(String base, String value) {
        if (value == null) value = "";
        if (base == null || base.isEmpty()) return value;
        return base + "\n" + value;
    }

    private static void extractKeyRefs(Prompt p, String line, String section) {
        ArrayList<String> keys = extractKeyRefs(line);
        for (String k : keys) {
            p.refs.add(k);
            if ("SUBJECT".equals(section) || "CHARACTERS".equals(section) || k.toUpperCase(Locale.US).startsWith("CHAR"))
                p.subjectRefs.add(k);
            else if ("SCENE".equals(section) || "LOCATION".equals(section) || k.toUpperCase(Locale.US).startsWith("SCENE") || k.toUpperCase(Locale.US).startsWith("LOCATION"))
                p.sceneRefs.add(k);
            else if ("STYLE".equals(section) || k.toUpperCase(Locale.US).startsWith("STYLE"))
                p.styleRefs.add(k);
        }
    }

    public static ArrayList<String> extractKeyRefs(String s) {
        ArrayList<String> out = new ArrayList<>();
        Matcher m = KEY_PATTERN.matcher(s == null ? "" : s);
        while (m.find()) out.add(cleanReferenceKey(m.group().trim()));
        return unique(out);
    }

    private static void finish(Prompt p, List<Prompt> out) {
        dedupeInPlace(p.refs);
        if (p.prompt == null) p.prompt = "";
        if (p.raw == null) p.raw = "";
        if (p.prompt.trim().isEmpty()) p.prompt = p.raw.trim();

        p.negative = p.negative == null ? "" : p.negative.trim();
        if (!p.negative.isEmpty() && !p.prompt.contains("NEGATIVE PROMPT:")) {
            p.prompt = p.prompt.trim() + "\n\nNEGATIVE PROMPT:\n" + p.negative;
        }

        dedupeInPlace(p.refs);
        dedupeInPlace(p.subjectRefs);
        dedupeInPlace(p.sceneRefs);
        dedupeInPlace(p.styleRefs);
        if (p.title == null || p.title.isEmpty())
            p.title = p.timestamp.isEmpty() ? "Prompt " + (out.size() + 1) : p.timestamp;
        p.status = "queued";
        p.error = "";
        p.stage = "";
        p.pendingDownloadId = -1L;
        p.pendingSourceUri = "";
        p.outputName = "";
        p.outputUri = "";
        out.add(p);
    }

    private static ArrayList<String> unique(List<String> in) {
        return new ArrayList<>(new LinkedHashSet<>(in));
    }
    private static void dedupeInPlace(List<String> list) {
        LinkedHashSet<String> s = new LinkedHashSet<>(list);
        list.clear();
        list.addAll(s);
    }

    private static List<Prompt> parseJson(String s) throws Exception {
        ArrayList<Prompt> out = new ArrayList<>();
        Object root = new JSONTokener(s).nextValue();
        JSONArray a;
        if (root instanceof JSONArray) a = (JSONArray) root;
        else {
            JSONObject o = (JSONObject) root;
            a = o.optJSONArray("prompts");
            if (a == null) a = o.optJSONArray("scenes");
            if (a == null) { a = new JSONArray(); a.put(o); }
        }

        for (int i = 0; i < a.length(); i++) {
            Object item = a.opt(i);
            Prompt p = new Prompt();
            if (item instanceof JSONObject) {
                JSONObject o = (JSONObject)item;
                p.timestamp = o.optString("timestamp", o.optString("time", ""));
                p.title = o.optString("title", p.timestamp);
                p.prompt = o.optString("FINAL IMAGE PROMPT", o.optString("prompt", o.optString("text", "")));
                p.raw = o.optString("raw", p.prompt);
                p.negative = o.optString("NEGATIVE PROMPT", o.optString("negative", ""));
                addJson(o, "refs", p.refs); addJson(o, "references", p.refs);
                addJson(o, "subjectRefs", p.subjectRefs); addJson(o, "subject", p.subjectRefs);
                addJson(o, "sceneRefs", p.sceneRefs); addJson(o, "scene", p.sceneRefs);
                addJson(o, "styleRefs", p.styleRefs); addJson(o, "style", p.styleRefs);
                ArrayList<String> found = extractKeyRefs(o.toString());
                p.refs.addAll(found);
                for (String k : found) {
                    String u = k.toUpperCase(Locale.US);
                    if (u.startsWith("CHAR") || u.startsWith("SUBJECT")) p.subjectRefs.add(k);
                    else if (u.startsWith("SCENE") || u.startsWith("LOCATION")) p.sceneRefs.add(k);
                    else if (u.startsWith("STYLE")) p.styleRefs.add(k);
                }
            } else {
                p.prompt = String.valueOf(item);
                p.raw = p.prompt;
            }
            if (!p.negative.isEmpty())
                p.prompt = p.prompt.trim() + "\n\nNEGATIVE PROMPT:\n" + p.negative.trim();
            p.refs.addAll(p.subjectRefs); p.refs.addAll(p.sceneRefs); p.refs.addAll(p.styleRefs);
            p.refs.replaceAll(PromptParser::cleanReferenceKey);
            p.subjectRefs.replaceAll(PromptParser::cleanReferenceKey);
            p.sceneRefs.replaceAll(PromptParser::cleanReferenceKey);
            p.styleRefs.replaceAll(PromptParser::cleanReferenceKey);
            dedupeInPlace(p.refs); dedupeInPlace(p.subjectRefs); dedupeInPlace(p.sceneRefs); dedupeInPlace(p.styleRefs);
            if (p.title == null || p.title.isEmpty()) p.title = p.timestamp.isEmpty() ? "Prompt " + (i + 1) : p.timestamp;
            p.status = "queued";
            out.add(p);
        }
        return out;
    }

    private static void addJson(JSONObject o, String key, List<String> dst) {
        Object v = o.opt(key);
        if (v == null || v == JSONObject.NULL) return;
        if (v instanceof JSONArray) {
            JSONArray a = (JSONArray)v;
            for (int i=0;i<a.length();i++) {
                String s = a.optString(i, "").trim();
                if (!s.isEmpty()) dst.add(cleanReferenceKey(s));
            }
        } else {
            String s = String.valueOf(v).trim();
            if (!s.isEmpty()) dst.add(cleanReferenceKey(s));
        }
    }

    private static final class Section {
        final String name; final String inlineValue;
        Section(String n, String v) { name=n; inlineValue=v; }
    }
}
