package com.jax.gemini;

import java.util.ArrayList;

public class Prompt {
    public String timestamp = "";
    public String raw = "";
    public String prompt = "";
    public String negative = "";
    public String title = "";

    public final ArrayList<String> refs = new ArrayList<>();
    public final ArrayList<String> subjectRefs = new ArrayList<>();
    public final ArrayList<String> sceneRefs = new ArrayList<>();
    public final ArrayList<String> styleRefs = new ArrayList<>();

    public String status = "queued";
    public String error = "";
    public String stage = "";

    // Crash-safe hand-off between Download and output-copy stages.
    public long pendingDownloadId = -1L;
    public String pendingSourceUri = "";
    public String outputName = "";
    public String outputUri = "";

    public Prompt() {}
}
