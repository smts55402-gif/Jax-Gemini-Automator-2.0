# Jax Gemini Automator — FRESH START

This guide intentionally starts from a clean repository. Do not mix files from the old 0.4.x builds into this project.

## A. Create the new GitHub repository

1. Open GitHub.
2. Tap **+** → **New repository**.
3. Repository name: `Jax-Gemini-Android-Automator-FINAL`.
4. Keep it empty. Do not add README, .gitignore, or license during creation.
5. Create the repository.

## B. Upload the final source package

Upload this file into the repository root:

`JAX_FINAL_CLEAN_SOURCE.zip`

Do not rename it.
Do not put it inside another folder.
Do not upload the older 0.4.x ZIPs.

## C. Add the GitHub Actions workflow

Create this exact path:

`.github/workflows/build-apk.yml`

Put the supplied `build-apk.yml` there. The workflow extracts the source package, verifies the Android project files, builds the debug APK, verifies that an APK exists, and uploads it as an Actions artifact.

## D. First build

1. Open **Actions**.
2. Open **Build Jax APK**.
3. Wait for the run to finish.
4. Only a green build is acceptable.
5. If it is red, stop there and inspect the first red `error:` line. Do not change multiple files at once.

## E. Install the APK

After a green run:

1. Open the successful run.
2. Open the artifact `Jax-Gemini-Android-Automator-v1.0.1-debug`.
3. Download the APK.
4. Install it as an update only if the package is the same; otherwise install normally.
5. Open Jax.

## F. Android setup

1. Open **Open Android Accessibility Settings**.
2. Enable **Jax Gemini Automator** accessibility service.
3. Return to Jax.
4. Open **Settings** and confirm the Quetta package is correct. Default is `net.quetta.browser`.
5. Keep the default output as `Downloads/Jax/...` for the first test.
6. Open **Gemini in Quetta** and leave Gemini ready.

## G. Reference preparation

For production, use filenames with stable IDs:

- `CHAR_01.png`, `CHAR_02.png`, ...
- `SCENE_01.png`, `SCENE_02.png`, ...
- `STYLE_01.png`, `STYLE_02.png`, ...

Add each group through the matching button.

Jax validates the reference names before starting. Duplicate normalized names across SUBJECT/SCENE/STYLE are rejected because the Android picker could otherwise select the wrong file.

Use **Prepare references for Android file picker** before the first reference test. Jax copies the reference files into `Downloads/Jax/References/` so the Android picker can find them by filename.

## H. Prompt format

Use one timestamped job per image:

```text
#00:00
SUBJECT:
CHAR_01.png
SCENE:
SCENE_01.png
STYLE:
STYLE_01.png

FINAL IMAGE PROMPT:
Your exact image-generation prompt here.
```

For 100 images, repeat this block for every timestamp. Each timestamp must be unique.

## I. Production safety ladder

Do not start with 100 jobs.

1. **1 prompt, 0 references** — proves Gemini navigation, prompt insertion, Generate/Send, Download, and output saving.
2. **1 prompt, 1 SUBJECT reference** — proves the file-picker path.
3. **1 prompt, SUBJECT + SCENE + STYLE** — proves full reference mapping.
4. **3 prompts** — proves sequential processing.
5. **10 prompts** — test STOP and START/RESUME.
6. **100 prompts** — only after the earlier tests pass.

A failed job is retried and then the batch pauses on that job. The queue cursor is persisted so START resumes from the unfinished job.

## J. Expected output

```text
Downloads/
└── Jax/
    └── Run-YYYY-MM-DD-HHmmss/
        ├── #00:00.png
        ├── #00:08.png
        ├── #00:16.png
        └── ...
```

Existing requested output files are not intentionally overwritten.

## Important limitation

Gemini/Quetta and Android's file picker are external UIs. Their accessibility labels and layout can change. Jax is designed to fail closed and pause rather than silently skip a job, but live testing on the actual phone/browser UI remains necessary before a 100-image production run.
