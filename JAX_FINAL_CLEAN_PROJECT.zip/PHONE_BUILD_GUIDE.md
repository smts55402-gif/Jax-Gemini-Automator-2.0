# Jax v1.0.0 — Phone-only GitHub build

## Existing repository method
The repository can keep the simple structure used for previous builds:

```text
JAX_FINAL_1.0.0_SOURCE.zip
.github/workflows/build-apk.yml
```

The GitHub workflow extracts the source package before building. The ZIP itself is intentionally not uploaded as the Android project root.

## Steps

1. Upload `JAX_FINAL_1.0.0_SOURCE.zip` to the repository root.
2. Open `.github/workflows/build-apk.yml` and make sure it is the workflow from this package.
3. Commit the changes to `main`.
4. Open Actions → Build Jax APK.
5. Wait for the run to finish.
6. Open the successful run → Artifacts → `Jax-Gemini-Android-Automator-v1.0.0-debug`.
7. Download and install the APK.

## Do not do this
- Do not upload the source ZIP inside `app/`.
- Do not delete the source ZIP after committing the workflow.
- Do not start a 100-job batch before completing the staged device tests.

## Current limitations
A GitHub build can validate compilation and package creation, but it cannot validate the live Quetta/Gemini accessibility tree on the user's phone. That final part has to be tested on the phone.
