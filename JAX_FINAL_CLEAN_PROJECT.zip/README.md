# Jax Gemini Automator v1.0.1 CLEAN FINAL BASELINE

## Purpose
Jax is a user-initiated Android AccessibilityService automation app for processing a timestamped Gemini image-generation queue one job at a time.

## Target workflow
100 jobs max:

1. Read a timestamped prompt job.
2. Validate the referenced SUBJECT / SCENE / STYLE files.
3. Open/verify Gemini in Quetta or the configured browser.
4. Start a clean Gemini chat when the UI exposes a New Chat control.
5. Attach each matched reference image one by one and verify each attachment.
6. Insert the exact FINAL IMAGE PROMPT text and verify it is present in the composer.
7. Press Generate/Send using accessibility labels/resource IDs and a spatial fallback for the unlabeled composer arrow.
8. Verify that generation actually started.
9. Wait for the generated result's Download/Save control.
10. Click Download/Save.
11. Detect the new DownloadManager/MediaStore image; reject old files.
12. Verify the downloaded file is readable.
13. Save a PNG copy using the exact timestamp filename, e.g. `#00:00.png`.
14. Verify the destination file exists.
15. Persist completion and advance the cursor.
16. Continue to the next job.

## Failure policy
A job is never silently skipped. A failed job is retried up to the configured retry count and then the batch pauses on that exact job.

STOP sets a persisted paused state. START acts as start/resume and uses the saved queue cursor.

A downloaded-but-not-yet-copied image is persisted as a pending source so a process death can recover the downloaded image instead of immediately generating a duplicate.

Existing output files are never intentionally overwritten. An existing requested filename causes the current job to pause rather than overwrite it.

## Input format
Recommended format:

```text
#00:00
SUBJECT:
CHAR_01.png
SCENE:
SCENE_01.png
STYLE:
STYLE_01.png

FINAL IMAGE PROMPT:
Your exact image-generation prompt here.
```

The parser also accepts `#AncientYou`, filenames, JSON, and escaped `\\n` line breaks. Reference IDs in SUBJECT/SCENE/STYLE sections are matched to the selected library by normalized filename base.

## Output
Default:

```text
Downloads/Jax/Run-YYYY-MM-DD-HHmmss/#00:00.png
Downloads/Jax/Run-YYYY-MM-DD-HHmmss/#00:08.png
```

The Settings screen can point Jax at a user-selected output folder instead.

## Production testing order
Do not start with 100 jobs. Verify the external Gemini/Quetta UI in this order:

`1 prompt / 0 refs` → `1 prompt / 1 ref` → `1 prompt / 3 refs` → `3 prompts` → `10 prompts with STOP/RESUME` → `100 prompts`.

Gemini/Quetta and Android DocumentsUI are external UIs. Their accessibility labels/layout can change. The app is designed to fail closed and pause rather than silently skip a job. Live device testing is still required because Gemini/Quetta and Android DocumentsUI are external UIs whose accessibility tree can change.
